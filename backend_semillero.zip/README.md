# 🎯 Semillero Mamba — Backend API

Sistema de Gestión de Proyectos y Productos de Investigación  
**Stack:** Python 3.11.10 · FastAPI · PostgreSQL · Docker · JWT

---

## 📁 Estructura del proyecto

```
semillero-mamba/
├── app/
│   ├── api/v1/
│   │   ├── endpoints/
│   │   │   ├── auth.py          # Login, registro, /me
│   │   │   ├── roles.py         # CRUD roles
│   │   │   ├── usuarios.py      # CRUD usuarios
│   │   │   ├── proyectos.py     # CRUD proyectos
│   │   │   ├── productos.py     # CRUD productos
│   │   │   ├── catalogos.py     # Grupos Minciencias + Tipos Producto
│   │   │   └── relaciones.py    # Proyecto-Usuarios + Producto-Autores
│   │   └── router.py
│   ├── core/
│   │   ├── config.py            # Variables de entorno (Pydantic Settings)
│   │   └── security.py          # JWT + bcrypt + dependencias auth
│   ├── db/
│   │   └── session.py           # Engine async + Base + get_db
│   ├── models/
│   │   └── models.py            # Todos los modelos SQLAlchemy (ER diagram)
│   ├── schemas/
│   │   └── schemas.py           # Todos los schemas Pydantic
│   ├── services/
│   │   ├── base.py              # CRUDBase genérico
│   │   ├── usuario_service.py   # Servicio con lógica de auth
│   │   └── services.py          # Instancias CRUD para cada modelo
│   └── main.py                  # App FastAPI + lifespan + CORS
├── alembic/                     # Migraciones de base de datos
├── tests/
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── alembic.ini
└── .env
```

---

## 🚀 Cómo correr el proyecto

### 1. Clonar y configurar variables de entorno

```bash
cp .env .env.local   # editar si necesitas cambiar claves
```

Editar `.env` y cambiar al menos:
```
SECRET_KEY=deja esa contraseña que tiene
```

### 2. Levantar con Docker Compose

en cd  semillero-mamba 
```bash
docker compose up --build
```

Esto levanta:
- **`mamba_db`** → PostgreSQL en el puerto `5432`
- **`mamba_api`** → FastAPI en el puerto `8000`

Las tablas se crean automáticamente al iniciar.

### 3. Acceder a la documentación interactiva

| URL | Descripción |
|-----|-------------|
| http://localhost:8000/api/docs | Swagger UI (recomendado) |
| http://localhost:8000/api/redoc | ReDoc |
| http://localhost:8000/ | Health check |

---

## 🔐 Flujo de autenticación JWT

```
POST /api/v1/auth/registro   →  Crear usuario
POST /api/v1/auth/login      →  Obtener token JWT
GET  /api/v1/auth/me         →  Ver perfil (requiere token)
```
### probar token jwt en swagger
---
#### primero va al apartado de arriba donde dice Authorize.
#### ahi pega el correo creado de auth junto con el password.
#### le unde en autorize y ya maneja ese token con el usuario.
---

### Ejemplo con curl

```bash
# 1. Registrar usuario
curl -X POST http://localhost:8000/api/v1/auth/registro \
  -H "Content-Type: application/json" \
  -d '{"nombre":"Admin","email":"admin@mamba.co","password":"admin1234"}'

# 2. Login → obtener token
curl -X POST http://localhost:8000/api/v1/auth/login \
  -F "username=admin@mamba.co" \
  -F "password=admin1234"

# 3. Usar token en requests protegidos
curl http://localhost:8000/api/v1/proyectos/ \
  -H "Authorization: Bearer <TOKEN>"
```



---

## 📋 Endpoints disponibles

| Método | Ruta | Descripción |
|--------|------|-------------|
| POST | `/api/v1/auth/registro` | Registro de usuario |
| POST | `/api/v1/auth/login` | Login → JWT |
| GET | `/api/v1/auth/me` | Perfil autenticado |
| GET/POST | `/api/v1/roles/` | Listar / crear roles |
| GET/PATCH/DELETE | `/api/v1/roles/{id}` | Detalle / editar / eliminar |
| GET/POST | `/api/v1/usuarios/` | Listar / crear usuarios |
| GET/PATCH/DELETE | `/api/v1/usuarios/{id}` | Detalle / editar / eliminar |
| GET/POST | `/api/v1/proyectos/` | Listar / crear proyectos |
| GET/PATCH/DELETE | `/api/v1/proyectos/{id}` | Detalle / editar / eliminar |
| GET/POST | `/api/v1/productos/` | Listar / crear productos |
| GET/PATCH/DELETE | `/api/v1/productos/{id}` | Detalle / editar / eliminar |
| GET/POST | `/api/v1/grupos-minciencias/` | Grupos de investigación |
| GET/POST | `/api/v1/tipos-producto/` | Tipos de producto |
| GET/POST | `/api/v1/proyecto-usuarios/` | Miembros de proyectos |
| GET/POST | `/api/v1/producto-autores/` | Autores de productos |

---

## 🔄 Migraciones con Alembic (opcional)

```bash
# Dentro del contenedor api
docker compose exec api alembic revision --autogenerate -m "inicial"
docker compose exec api alembic upgrade head
```

---

## 🛠️ Comandos útiles

```bash
# Ver logs en tiempo real
docker compose logs -f api

# Reiniciar solo la API (sin reconstruir)
docker compose restart api

# Entrar al contenedor
docker compose exec api bash

# Detener todo
docker compose down

# Detener y borrar volúmenes (⚠️ borra la BD)
docker compose down -v
```
