from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import get_current_active_user
from app.db.session import get_db
from app.schemas.schemas import ProyectoCreate, ProyectoUpdate, ProyectoOut
from app.services.services import ProyectoService

router = APIRouter(prefix="/proyectos", tags=["Proyectos"])


@router.get("/", response_model=list[ProyectoOut])
async def listar(skip: int = 0, limit: int = 100, db: AsyncSession = Depends(get_db), _=Depends(get_current_active_user)):
    return await ProyectoService.get_multi(db, skip=skip, limit=limit)


@router.get("/{id}", response_model=ProyectoOut)
async def obtener(id: int, db: AsyncSession = Depends(get_db), _=Depends(get_current_active_user)):
    obj = await ProyectoService.get(db, id)
    if not obj:
        raise HTTPException(404, "Proyecto no encontrado")
    return obj


@router.post("/", response_model=ProyectoOut, status_code=201)
async def crear(payload: ProyectoCreate, db: AsyncSession = Depends(get_db), current_user=Depends(get_current_active_user)):
    data = payload.model_dump()
    data["creado_por"] = current_user.id
    from app.models.models import Proyecto
    obj = Proyecto(**data)
    db.add(obj)
    await db.flush()
    await db.refresh(obj)
    return obj


@router.patch("/{id}", response_model=ProyectoOut)
async def actualizar(id: int, payload: ProyectoUpdate, db: AsyncSession = Depends(get_db), _=Depends(get_current_active_user)):
    obj = await ProyectoService.get(db, id)
    if not obj:
        raise HTTPException(404, "Proyecto no encontrado")
    return await ProyectoService.update(db, db_obj=obj, obj_in=payload)


@router.delete("/{id}", status_code=204)
async def eliminar(id: int, db: AsyncSession = Depends(get_db), _=Depends(get_current_active_user)):
    obj = await ProyectoService.remove(db, id=id)
    if not obj:
        raise HTTPException(404, "Proyecto no encontrado")
