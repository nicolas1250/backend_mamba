from fastapi import Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.security import get_current_active_user
from app.db.session import get_db

def require_permission(modulo: str, accion: str):

    async def permission_checker(
        current_user = Depends(get_current_active_user),
        db: AsyncSession = Depends(get_db)
    ):
        rol = current_user.rol

        if not rol:
            raise HTTPException(403, "Usuario sin rol")

        permisos = [rp.permiso for rp in rol.roles_permisos]

        for p in permisos:
            if p.modulo == modulo and p.accion == accion:
                return current_user

        raise HTTPException(403, detail="No tienes permisos")

    return permission_checker